package com.task3.entity;

public class Processor {
       private String processor;
       
       public String getProcessor() {
		return processor;
	}

	public void setProcessor(String processor) {
		this.processor = processor;
	}

	@Override
       public String toString()
       {
    	   return processor;
       }
	
	
}
