package com.task3.entity;

public class Laptop {
   private String name;
   private Processor p;
   public Laptop(String name, Processor p) {
		super();
		this.name = name;
		this.p = p;
	}
//   public Laptop(String n , Processor p)
//   {
//	   this.name=n;
//	   this.p=p;
//	   
//   }/
   
   
   public void displayLaptop()
   {
	   System.out.println("Name of the Laptop:"+ name);
	   System.out.println("Welcome to windows!"+ p +" have started !");
   }

}
