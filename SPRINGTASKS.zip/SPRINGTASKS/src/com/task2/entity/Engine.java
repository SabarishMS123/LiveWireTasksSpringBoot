package com.task2.entity;

public class Engine {
   public void start()
   {
	   System.out.println("Engine started..");
   }
}
