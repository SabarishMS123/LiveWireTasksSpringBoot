package com.task2.entity;

public class Car {
   private Engine engine;
   //The setter method
   public void setEngine(Engine engine)
   {
	   this.engine=engine;
   }
   public void drive()
   {
	   engine.start();
	   System.out.println("The car have started and moving succesfully..");
   }
}
