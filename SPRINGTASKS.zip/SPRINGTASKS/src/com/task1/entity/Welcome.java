package com.task1.entity;

public class Welcome {
          private String welcome;

		public String getWelcome() {
			return welcome;
		}

		public void setWelcome(String welcome) {
			this.welcome = welcome;
		}
          
		public void displayMessage()
		{
		   System.out.println("You're Message :"+ welcome);
		}
}
