package com.task1.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.task1.entity.Welcome;
import com.task2.entity.Car;
import com.task3.entity.Laptop;
import com.task4.entity.Student;
public class Main {
	
	public static void main(String[]args) {
       ApplicationContext context = new ClassPathXmlApplicationContext("com/task1/resources/applicationContext.xml");
       Welcome w =(Welcome) context.getBean("welc");
       System.out.println("Task 1 output:");
       w.displayMessage();
       
       
       System.out.println("=================================");
       System.out.println("Task 2 output:");
       Car c=(Car) context.getBean("car");
       c.drive();
       
       System.out.println("=================================");
       System.out.println("Task 3 output:");
       Laptop l=(Laptop) context.getBean("lap",Laptop.class);
       l.displayLaptop();
       
       System.out.println("=================================");
       System.out.println("Task 4 output:");
       Student s=(Student)context.getBean("stu");
       s.display();
       
       
       
     
}}
