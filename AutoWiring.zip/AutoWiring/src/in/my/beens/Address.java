package in.my.beens;

public class Address {
     String city,state; int room_no;

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public int getRoom_no() {
		return room_no;
	}

	public void setRoom_no(int room_no) {
		this.room_no = room_no;
	}
     @Override
     public String toString()
     {
    	 return room_no+" "+city+" "+state;
     }
}
