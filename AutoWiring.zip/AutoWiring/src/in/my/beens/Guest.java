package in.my.beens;

import org.springframework.beans.factory.annotation.Autowired;

public class Guest {
    public Address getAddress()
    {
    	return address;
    }
    public void setAddress(Address address)
    {
    	this.address=address;
    }
    int ID,age; String name;
    
    @Autowired
    Address address;
    public void display()
    
    {
    	System.out.println("Name:"+name);
    	System.out.println("Age:"+age);
    	
    	System.out.println("Address:"+address);
    	
    }
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
