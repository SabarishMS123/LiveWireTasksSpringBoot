package in.my.resource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import in.my.beens.Address;
import in.my.beens.Guest;

@Configuration
public class SpringConfigFile {
	
	@Bean
	public Address createAddrObj()
	{
		Address addr=new Address();
		addr.setCity("salem");
		addr.setRoom_no(123);
		addr.setState("Tamil nadu");
		
		return addr;
	}
	@Bean
	public Guest createGuesObj()
	{
		Guest gues=new Guest();
		gues.setID(1);
		gues.setAge(20);
		gues.setName("ram");
//		gues.setAddress(createAddrObj());
		
		return gues;
		
	}

}
