package in.example;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        if(username != null && password != null &&
           username.equals("admin") && password.equals("1234")) {

            // 🔹 Create Session
            HttpSession session = request.getSession();
            session.setAttribute("user", username);
            session.setMaxInactiveInterval(600); // 10 minutes

            // 🔹 Create Cookie
            Cookie cookie = new Cookie("username", username);
            cookie.setMaxAge(3600); // 1 hour
            cookie.setHttpOnly(true);
            response.addCookie(cookie);

            response.sendRedirect("dashboard");

        } else {

            response.setContentType("text/html");
            PrintWriter out = response.getWriter();

            out.println("<h3>Invalid Credentials</h3>");
            out.println("<a href='login.html'>Try Again</a>");
        }
    }
}

