package in.example;

import java.io.*;


import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/dashboard")
public class DashboardServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        if(session == null || session.getAttribute("user") == null) {
            response.sendRedirect("login.html");
            return;
        }

        String user = (String) session.getAttribute("user");

        // 🔹 Get Cookie
        String cookieUser = "";
        Cookie[] cookies = request.getCookies();

        if(cookies != null) {
            for(Cookie c : cookies) {
                if(c.getName().equals("username")) {
                    cookieUser = c.getValue();
                }
            }
        }

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<html><head><title>Dashboard</title></head><body>");
        out.println("<h2>Dashboard Page</h2>");
        out.println("<p>Welcome (Session): " + user + "</p>");
        out.println("<p>Welcome (Cookie): " + cookieUser + "</p>");
        out.println("<br><a href='logout'>Logout</a>");
        out.println("</body></html>");
    }
}
