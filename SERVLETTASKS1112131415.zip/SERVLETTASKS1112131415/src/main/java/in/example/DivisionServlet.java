package in.example;



import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/divide")
public class DivisionServlet extends HttpServlet {

//    protected void doPost(HttpServletRequest request, HttpServletResponse response)
//            throws ServletException, IOException {
//
//        response.setContentType("text/html");
//        PrintWriter out = response.getWriter();
//
//        out.println("<html><body>");
//        out.println("<h2>Division Result</h2>");
//
//        try {
//            int num1 = Integer.parseInt(request.getParameter("num1"));
//            int num2 = Integer.parseInt(request.getParameter("num2"));
//
//            int result = num1 / num2;
//
//            out.println("<h3>Result: " + result + "</h3>");
//
//        } catch (ArithmeticException e) {
//
//            out.println("<h3 style='color:red;'>❌ Cannot divide by zero!</h3>");
//
//        } catch (NumberFormatException e) {
//
//            out.println("<h3 style='color:red;'>❌ Please enter valid numbers!</h3>");
//
//        } catch (Exception e) {
//
//            out.println("<h3 style='color:red;'>❌ Something went wrong!</h3>");
//        }
//
//        out.println("</body></html>");
//    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
	        throws ServletException, IOException {

	    int x = 10 / 0;   // This causes 500 error
	}

}

