package com.example;

import java.io.IOException;
import java.util.ArrayList;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;


@WebServlet("/CartServlet")
public class CartServlet extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        
        String newItem = request.getParameter("item");
        
       
        HttpSession session = request.getSession();
        
     
        ArrayList<String> cart = (ArrayList<String>) session.getAttribute("myCart");
        if (cart == null) {
            cart = new ArrayList<>();
        }
        
      
        if (newItem != null) {
            cart.add(newItem);
        }
        

        session.setAttribute("myCart", cart);
        response.sendRedirect("shop.jsp");
    }
}
