package com.example;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/CalculatorServlet")
public class CalculatorServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        try {
           
            int n1 = Integer.parseInt(request.getParameter("num1"));
            int n2 = Integer.parseInt(request.getParameter("num2"));
            String op = request.getParameter("operation");
            int result = 0;

           
            if (op.equals("add")) {
                result = n1 + n2;
            } else if (op.equals("sub")) {
                result = n1 - n2;
            }

        
            request.setAttribute("calcResult", result);
            
        } catch (NumberFormatException e) {
          
            request.setAttribute("error", "Please enter valid numbers!");
        }

       
        request.getRequestDispatcher("result1.jsp").forward(request, response);
    }
}