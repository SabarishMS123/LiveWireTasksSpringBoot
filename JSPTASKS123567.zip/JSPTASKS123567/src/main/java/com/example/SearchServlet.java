package com.example;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/SearchServlet")
public class SearchServlet extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
      
        List<String> students = Arrays.asList("Tharun", "Tharunika", "Sabarish", "Subha Shree", "Karthikeyan");
        
      
        String query = request.getParameter("query");
        String match = null;

   
        for (String name : students) {
            if (name.equalsIgnoreCase(query)) {
                match = name;
                break; 
            }
        }

      
        request.setAttribute("resultName", match);
        request.getRequestDispatcher("result3.jsp").forward(request, response);
    }
}