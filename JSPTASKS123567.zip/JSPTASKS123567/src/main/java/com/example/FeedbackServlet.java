package com.example;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/FeedbackServlet")
public class FeedbackServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
       
        String name = request.getParameter("userName");
        String rating = request.getParameter("rating");
        String comments = request.getParameter("comments");

   
        request.setAttribute("uName", name);
        request.setAttribute("uRating", rating);
        request.setAttribute("uComments", comments);

       
        request.getRequestDispatcher("viewFeedback.jsp").forward(request, response);
    }
}
