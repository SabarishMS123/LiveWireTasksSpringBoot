package com.example;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/AgeServlet")
public class AgeServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String ageStr = request.getParameter("userAge");
        String message;

        try {
            if (ageStr == null || ageStr.trim().isEmpty()) {
                message = "Please enter a valid age.";
            } else {
                int age = Integer.parseInt(ageStr);

                
                if (age >= 18) {
                    message = "Eligible";
                } else {
                    message = "Not Eligible";
                }
            }
        } catch (NumberFormatException e) {
            message = "Invalid input! Please enter a number.";
        }

        
        request.setAttribute("status", message);
        request.getRequestDispatcher("result.jsp").forward(request, response);
    }
}
