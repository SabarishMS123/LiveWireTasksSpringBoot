package com.example;

import java.io.IOException;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/ContactServlet")
public class ContactServlet extends HttpServlet {
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        
        String name = request.getParameter("userName");
        String email = request.getParameter("userEmail");
        String message = request.getParameter("userMsg");

       
        System.out.println("Received contact from: " + name + " [" + email + "]");

       
        request.setAttribute("confirmedName", name);

        
        RequestDispatcher dispatcher = request.getRequestDispatcher("thankyou.jsp");
        dispatcher.forward(request, response);
    }
}
