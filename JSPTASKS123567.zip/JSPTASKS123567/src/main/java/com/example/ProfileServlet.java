package com.example;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
@WebServlet("/ProfileServlet")
public class ProfileServlet extends HttpServlet{
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
	        throws ServletException, IOException {
	    
	   
	    String name = request.getParameter("userName");
	    String dept = request.getParameter("dept");

	 
	    HttpSession session = request.getSession();
	    session.setAttribute("uName", name);
	    session.setAttribute("uDept", dept);

	    
	    response.sendRedirect("profile.jsp");
	}
}
