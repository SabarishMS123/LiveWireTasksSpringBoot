<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ page import="java.util.ArrayList" %>
<!DOCTYPE html>
<html>
<head>
    <title>Your Cart</title>
</head>
<body>
    <h2>Items in Your Cart</h2>
    
    <ul>
    <% 
        ArrayList<String> cart = (ArrayList<String>) session.getAttribute("myCart");
        if (cart != null && !cart.isEmpty()) {
            for (String item : cart) {
    %>
                <li><%= item %></li>
    <% 
            }
        } else {
    %>
            <li>Your cart is empty!</li>
    <% } %>
    </ul>

    <hr>
    <h3>Total Items: <%= (cart != null) ? cart.size() : 0 %></h3>
    
    <a href="shop.jsp">Keep Shopping</a> | 
  
</body>
</html>