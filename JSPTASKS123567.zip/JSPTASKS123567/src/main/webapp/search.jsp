<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Student Search</title>
</head>
<body>
    <h2>Search Student Directory</h2>
    <form action="SearchServlet" method="GET">
        <input type="text" name="query" placeholder="Enter student name..." required>
        <button type="submit">Search</button>
    </form>
</body>
</html>