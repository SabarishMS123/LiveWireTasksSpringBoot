<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Mini Shop</title>
</head>
<body>
    <h2>Available Products</h2>
    <table border="1">
        <tr>
            <th>Product</th>
            <th>Action</th>
        </tr>
        <tr>
            <td>Smartphone</td>
            <td><a href="CartServlet?item=Smartphone">Add to Cart</a></td>
        </tr>
        <tr>
            <td>Laptop</td>
            <td><a href="CartServlet?item=Laptop">Add to Cart</a></td>
        </tr>
        <tr>
            <td>Headphones</td>
            <td><a href="CartServlet?item=Headphones">Add to Cart</a></td>
        </tr>
    </table>
    <br>
    <a href="cart.jsp">View My Cart</a>
</body>
</html>