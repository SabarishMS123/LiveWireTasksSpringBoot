<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<form action="ProfileServlet" method="POST">
    Name: <input type="text" name="userName"><br>
    Dept: <input type="text" name="dept"><br>
    <button type="submit">Save Profile</button>
</form>
</body>
</html>