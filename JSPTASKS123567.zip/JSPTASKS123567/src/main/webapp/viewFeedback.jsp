<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Feedback Received</title>
    <style>
        table { border-collapse: collapse; width: 50%; }
        th, td { border: 1px solid black; padding: 10px; text-align: left; }
    </style>
</head>
<body>
    <h2>Feedback Summary</h2>
    <table>
        <tr>
            <th>Field</th>
            <th>Details</th>
        </tr>
        <tr>
            <td><strong>Name</strong></td>
            <td>${uName}</td>
        </tr>
        <tr>
            <td><strong>Rating</strong></td>
            <td>${uRating} / 5</td>
        </tr>
        <tr>
            <td><strong>Comments</strong></td>
            <td>${uComments}</td>
        </tr>
    </table>
    <br>
    <a href="feedback.jsp">Submit another response</a>
</body>
</html>