<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Contact Us</title>
</head>
<body>
    <h2>Contact Form</h2>
    <form action="ContactServlet" method="POST">
        <label>Name:</label><br>
        <input type="text" name="userName" required><br><br>

        <label>Email:</label><br>
        <input type="email" name="userEmail" required><br><br>

        <label>Message:</label><br>
        <textarea name="userMsg" required></textarea><br><br>

        <button type="submit">Submit</button>
    </form>
</body>
</html>