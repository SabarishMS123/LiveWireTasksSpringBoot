<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Calculation Result</title>
</head>
<body>
    <h2>Result</h2>
    
    <p style="color: red;">${error}</p>
    
    <h3 style="display: ${empty error ? 'block' : 'none'}">
        The answer is: <strong>${calcResult}</strong>
    </h3>

    <a href="calculator.jsp">Back to Calculator</a>
</body>
</html>