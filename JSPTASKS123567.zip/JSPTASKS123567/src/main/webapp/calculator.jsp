<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Simple Calculator</title>
</head>
<body>
    <h2>Basic Arithmetic</h2>
    <form action="CalculatorServlet" method="POST">
        <input type="number" name="num1" placeholder="First Number" required>
        
        <select name="operation">
            <option value="add">+</option>
            <option value="sub">-</option>
        </select>
        
        <input type="number" name="num2" placeholder="Second Number" required>
        
        <button type="submit">Calculate</button>
    </form>
</body>
</html>