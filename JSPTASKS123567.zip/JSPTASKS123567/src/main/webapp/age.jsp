<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Age Checker</title>
</head>
<body>
    <h2>Check Your Eligibility</h2>
    <form action="AgeServlet" method="POST">
        <label>Enter your age:</label>
        <input type="number" name="userAge" required>
        <button type="submit">Check Status</button>
    </form>
</body>
</html>