<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Success</title>
</head>
<body>
    <h1>Submission Received!</h1>
    <% 
        // Retrieve the attribute set by the Servlet
        String name = (String) request.getAttribute("confirmedName"); 
    %>
    <p>Thank you, <strong><%= name %></strong> for contacting us!</p>
    
    <a href="contact.jsp">Back to Form</a>
</body>
</html>