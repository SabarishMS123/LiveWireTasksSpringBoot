<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Submit Feedback</title>
</head>
<body>
    <h2>Customer Feedback Form</h2>
    <form action="FeedbackServlet" method="POST">
        <label>Name:</label><br>
        <input type="text" name="userName" required><br><br>

        <label>Rating:</label><br>
        <select name="rating">
            <option value="1">1 - Poor</option>
            <option value="2">2 - Fair</option>
            <option value="3">3 - Good</option>
            <option value="4">4 - Very Good</option>
            <option value="5">5 - Excellent</option>
        </select><br><br>

        <label>Comments:</label><br>
        <textarea name="comments" rows="4" cols="30"></textarea><br><br>

        <button type="submit">Submit Feedback</button>
    </form>
</body>
</html>