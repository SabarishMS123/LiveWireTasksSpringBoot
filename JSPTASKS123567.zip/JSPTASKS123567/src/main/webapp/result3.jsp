<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
    <title>Search Result</title>
</head>
<body>
    <h2>Search Result</h2>
    
    <% 
        String result = (String) request.getAttribute("resultName");
        if (result != null) { 
    %>
        <p style="color: green;">✔ Success: Student <strong><%= result %></strong> was found!</p>
    <% 
        } else { 
    %>
        <p style="color: red;">❌ No result found.</p>
    <% 
        } 
    %>
    
    <br>
    <a href="search.jsp">Back to Search</a>
</body>
</html>