<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<%
    // This clears all data bound to the session
    session.invalidate(); 
    
    // Redirect back to login/form page
    response.sendRedirect("profileForm.jsp");
%>
</body>
</html>