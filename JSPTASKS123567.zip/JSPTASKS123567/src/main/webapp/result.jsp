<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Eligibility Result</title>
</head>
<body>
    <h1>Result</h1>
    <% 
        String result = (String) request.getAttribute("status"); 
    %>
    
    <p>Status: <strong><%= result %></strong></p>
    
    <hr>
    <a href="age.jsp">Try Again</a>
</body>
</html>