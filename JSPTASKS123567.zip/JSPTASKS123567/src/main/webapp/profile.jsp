<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<%
    // Check if session exists to prevent unauthorized access
    String name = (String) session.getAttribute("uName");
    if(name == null) {
        response.sendRedirect("profileForm.jsp");
    }
%>

<h2>Welcome, <%= name %></h2>
<p>Department: <%= session.getAttribute("uDept") %></p>

<a href="logout.jsp">Logout</a>
</body>
</html>