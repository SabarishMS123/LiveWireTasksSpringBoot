package in.my.resources;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import in.my.beens.Address;
import in.my.beens.Student;
import in.my.beens.Subject;
//@Qualifier -->near to autowire annotated place , only right bean class is there..
@Configuration
public class SpringConfigFile {
              @Bean
              public Student student()
              {
            	  Student std = new Student();
            	  std.setName("Saboo");
            	  std.setRoll_no(123);
            	  return std;
              }
              
              @Bean
              public Address address()
              {
            	  Address a= new Address();
            	  a.setCity("Salem");
            	  a.setState("TN");
            	  a.setPincode(636006);
            	  return a;
              }
              
              @Bean
              public Subject subjects()
              {
            	  Subject s = new Subject();
            	  List<String> su = new ArrayList<String>();
            	  su.add("Tamil");
            	  su.add("English");
            	  su.add("Maths");
            	  s.setSubjects(su);
            	  return s;
              }
}
