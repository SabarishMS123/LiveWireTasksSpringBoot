package in.my.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import in.my.beens.Student;
import in.my.resources.SpringConfigFile;



public class Main {
   public static void main(String[]args) {
	   
	   ApplicationContext context=new AnnotationConfigApplicationContext(SpringConfigFile.class);
	   Student std =(Student)context.getBean(Student.class);
	   std.displayStudent();
   }
}
