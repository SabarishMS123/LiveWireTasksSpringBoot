package in.my.beens;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class Student {
    private String name ;
    private int roll_no;
    @Autowired
    @Qualifier("address")
    private Address address;
    
    @Autowired
    private Subject subjects;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getRoll_no() {
		return roll_no;
	}
	public void setRoll_no(int roll_no) {
		this.roll_no = roll_no;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	
	public void displayStudent()
	{
		System.out.println("Name:"+ name);
		System.out.println("Roll No:"+roll_no);
		System.out.println("Address:"+address);
		System.out.println("Subjects:"+ subjects);
		
	}
	public Subject getSubject() {
		return subjects;
	}
	public void setSubject(Subject subjects) {
		this.subjects = subjects;
	}
}
