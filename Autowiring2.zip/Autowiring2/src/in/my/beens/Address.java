package in.my.beens;

public class Address {
     private String State;
     private String city;
     private int pincode;
	public String getState() {
		return State;
	}
	public void setState(String state) {
		State = state;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getPincode() {
		return pincode;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
    @Override
    public String toString()
    {
    	return State+","+city+"-"+pincode;
    }
}
