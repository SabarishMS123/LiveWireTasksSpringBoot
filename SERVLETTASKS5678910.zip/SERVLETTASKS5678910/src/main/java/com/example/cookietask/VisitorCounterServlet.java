package com.example.cookietask;


import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/visitor")
public class VisitorCounterServlet extends HttpServlet {

    // Servlet lifecycle variable
    private int visitorCount = 0;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Increase count
        visitorCount++;

        // Auto refresh every 5 seconds
        response.setIntHeader("Refresh", 5);

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<html><body>");
        out.println("<h2>Visitor Counter</h2>");
        out.println("<h3>Total Visitors: " + visitorCount + "</h3>");
        out.println("<p>Page refreshes every 5 seconds</p>");
        out.println("</body></html>");
    }
}

