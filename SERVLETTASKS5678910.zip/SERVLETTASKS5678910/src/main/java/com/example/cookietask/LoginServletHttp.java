package com.example.cookietask;



import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/login3")
public class LoginServletHttp extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        if ("admin".equals(username) && "1234".equals(password)) {

            // Create or get existing session
            HttpSession session = request.getSession();

            // Store data in session
            session.setAttribute("user", username);

            // Redirect to welcome servlet
            response.sendRedirect("welcome");

        } else {
            response.sendRedirect("error.html");
        }
    }
}

