package com.example.cookietask;



import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/welcome")
public class WelcomeServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        HttpSession session = request.getSession(false);

        out.println("<html><body>");

        if (session != null && session.getAttribute("user") != null) {

            String username = (String) session.getAttribute("user");

            out.println("<h2>Welcome " + username + " 🎉</h2>");
            out.println("<a href='logout'>Logout</a>");

        } else {
            out.println("<h2>Session expired ❌</h2>");
        }

        out.println("</body></html>");
    }
}

