package com.example.cookietask;



import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/time")
public class TimeServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Set refresh time to 5 seconds
        response.setIntHeader("Refresh", 5);

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        Date currentDate = new Date();

        out.println("<html><body>");
        out.println("<h2>Current Date & Time</h2>");
        out.println("<h3>" + currentDate.toString() + "</h3>");
        out.println("<p>Page refreshes every 5 seconds...</p>");
        out.println("</body></html>");
    }
}

