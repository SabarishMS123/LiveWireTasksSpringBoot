package com.in;

import java.io.*;
import java.util.*;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;


@WebServlet("/upload")
@MultipartConfig(
    fileSizeThreshold = 1024 * 1024,
    maxFileSize = 1024 * 1024 * 5,
    maxRequestSize = 1024 * 1024 * 10
)
public class UploadServlet extends HttpServlet {

    private static final String UPLOAD_DIR = "uploads";

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // 🔹 Session Check
        HttpSession session = request.getSession(false);
        if(session == null || session.getAttribute("user") == null) {
            response.sendRedirect("login.html");
            return;
        }

        String path = getServletContext().getRealPath("") + File.separator + UPLOAD_DIR;
        File uploadDir = new File(path);

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<h2>Uploaded Files</h2>");

        if(uploadDir.exists()) {
            for(File file : uploadDir.listFiles()) {
                out.println(file.getName() + "<br>");
            }
        }

        out.println("<br><a href='upload.html'>Back</a>");
        out.println("<br><a href='logout'>Logout</a>");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // 🔹 Session Check
        HttpSession session = request.getSession(false);
        if(session == null || session.getAttribute("user") == null) {
            response.sendRedirect("login.html");
            return;
        }

        String uploadPath = getServletContext().getRealPath("") + File.separator + UPLOAD_DIR;
        File uploadDir = new File(uploadPath);
        if(!uploadDir.exists()) uploadDir.mkdir();

        for(Part part : request.getParts()) {
            String fileName = part.getSubmittedFileName();
            if(fileName != null && !fileName.isEmpty()) {
                part.write(uploadPath + File.separator + fileName);
            }
        }

        response.getWriter().println("File Uploaded Successfully!<br>");
        response.getWriter().println("<a href='upload.html'>Upload Another</a><br>");
        response.getWriter().println("<a href='upload'>View Files</a>");
    }
}
