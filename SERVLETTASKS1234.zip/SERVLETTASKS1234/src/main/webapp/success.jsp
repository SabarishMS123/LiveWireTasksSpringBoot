<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
      <h2 style="color:green;">
    Welcome, <%= request.getAttribute("user") %> ✅
</h2>
</body>
</html>