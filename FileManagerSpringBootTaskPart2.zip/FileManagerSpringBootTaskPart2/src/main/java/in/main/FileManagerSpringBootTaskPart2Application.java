package in.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FileManagerSpringBootTaskPart2Application {

	public static void main(String[] args) {
		SpringApplication.run(FileManagerSpringBootTaskPart2Application.class, args);
	}

}
