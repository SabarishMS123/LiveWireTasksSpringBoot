package in.my.main;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
//import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


import in.my.beens.Student;

public class Main {
  public static void main(String [] args)
  {
	  
	  ApplicationContext context=new ClassPathXmlApplicationContext ("in/my/resource/Springconfig.xml");
	  Student std =(Student)context.getBean("std");
	  std.displayStudent();
	 
	 
  }}
