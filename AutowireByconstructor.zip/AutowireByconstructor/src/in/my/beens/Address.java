package in.my.beens;

public class Address {
       private String State;
       private String City;
       private String pincode;
		
		public Address(String state, String city, String pincode) {
		super();
		State = state;
		City = city;
		this.pincode = pincode;
	}

		@Override
		public String toString()
		{
			return State+","+City+"-"+pincode;
			
		}
       
}
